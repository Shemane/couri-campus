export default [
  require("C:\\Users\\shema\\www\\cowrie-campus\\.docusaurus\\docusaurus-plugin-css-cascade-layers\\default\\layers.css"),
  require("C:\\Users\\shema\\www\\cowrie-campus\\node_modules\\infima\\dist\\css\\default\\default.css"),
  require("C:\\Users\\shema\\www\\cowrie-campus\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages"),
  require("C:\\Users\\shema\\www\\cowrie-campus\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress"),
  require("C:\\Users\\shema\\www\\cowrie-campus\\src\\css\\custom.css"),
];
