---
id: intro
title: Welcome to the Cowrie Campus
sidebar_position: 1
---

Welcome to the Cowrie Small Business Institute! This module introduces our mission, your learning journey, and how to navigate the platform.

### What You'll Learn
- How Cowrie empowers SMEs and creative founders
- How to access your dashboard and learning tracks
- What to expect from each module

Let’s begin your journey toward scalable impact.
